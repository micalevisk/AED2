/* === [ordenacaoParcial.c] === */
// ...
void ajustarHeap(TTAD* t, int pai, int posUltimo){
  TDadoTAD *d = t->dado;
  TArrayDinamico *vet = d->vetorFila;
  void *aux;
  int esq, dir, posAtual;

  esq = 2*pai + 1;
  dir = esq + 1;
  posAtual = pai;

  if( (esq <= posUltimo)
    && COMPARAR_PRIORIDADES(vet->acessar(vet, esq), vet->acessar(vet, posAtual)) )
    posAtual = esq;
  if( (dir <= posUltimo)
    && COMPARAR_PRIORIDADES(vet->acessar(vet, dir), vet->acessar(vet, posAtual)) )
    posAtual = dir;

  if(posAtual != pai){
    aux = vet->acessar(vet, pai);
    vet->atualizar(vet, pai, vet->acessar(vet, posAtual));
    vet->atualizar(vet, posAtual, aux);

    t->movimentacoes_desenfileirar++;
    ajustarHeap(t, posAtual, posUltimo);
  }

}
