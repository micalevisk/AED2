/* === [ordenacaoCompleta.c] e [ordenacaoParcial.c] === */
#include "ordenacaoFila.h"
#include <stdlib.h>
