/* === [ordenacaoCompleta.c] === */
typedef struct{
  TArrayDinamico *vetorFila;
  int posPrimeiro;
  int posUltimo;

}TDadoTAD;

/* === [ordencaoParcial.c] === */
#define PAI(i) (((i)-1)/2)

typedef struct{
  TArrayDinamico *vetorFila;
  int ocupacao;

}TDadoTAD;
